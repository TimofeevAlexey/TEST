Munee: Standalone PHP 5.3 Asset Optimisation &amp; Manipulation
===============================================================

#####On-The-Fly Image Resizing, On-the-fly LESS, SCSS, CoffeeScript Compiling, CSS &amp; JavaScript Combining/Minifying, and Smart Client Side and Server Side Caching

[![Build Status](https://secure.travis-ci.org/meenie/munee.png?branch=master)](http://travis-ci.org/meenie/munee)
[![Flatter this](http://api.flattr.com/button/flattr-badge-large.png)](http://flattr.com/thing/1191331/)
[![Bitdeli Badge](https://d2weczhvl823v0.cloudfront.net/meenie/munee/trend.png)](https://bitdeli.com/free "Bitdeli Badge")
[![githalytics.com alpha](https://cruel-carlota.pagodabox.com/52ec078beb235f390c05c38ccf8ea852 "githalytics.com")](http://githalytics.com/meenie/munee)

---

#### [Official Website](http://mun.ee)
#### [Documentation](http://mun.ee/Introducing_Munee)
#### [API](http://mun.ee/api/index.html)
